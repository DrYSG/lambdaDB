var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'ygutfreund',
applicationName: 'lambdadb',
appUid: 'DfHz3k2KpbZGdVT9T3',
tenantUid: 'y4jQk0ckJQNBvJ544j',
deploymentUid: '3e8fa676-715e-4a35-95fc-133069d8e177',
serviceName: 'lambdadb',
stageName: 'dev',
pluginVersion: '3.2.3'})
const handlerWrapperArgs = { functionName: 'lambdadb-dev-dbConn', timeout: 6}
try {
  const userHandler = require('./main.js')
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
