# lambdaDB
AWS Lambda Function connects to PostgresDB
